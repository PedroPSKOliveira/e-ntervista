package com.ifba.entervista;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntervistaApplicationTests {

	@Test
	void contextLoads() {
	}

}
